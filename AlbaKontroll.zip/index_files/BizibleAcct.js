(function () {
    BizTrackingA.GoAccount({
        accountid: 'bluefountainmedia',
        webToLeadField: '',
        chatEnabled: 'false' === 'true',
        XUserId: '',
        formProviderEnabled: 'false' === 'true'
    });
})();
;